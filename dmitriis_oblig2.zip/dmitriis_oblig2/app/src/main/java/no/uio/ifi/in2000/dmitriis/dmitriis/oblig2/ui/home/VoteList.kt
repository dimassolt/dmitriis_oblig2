
package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.ui.home


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.alpacas.PartyInfo

var stemmer: Int = 123

@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun viseFremStemmer(partiesViewModel: HomeViewModel = viewModel()) {
    val partiesUiState: PartiesUiState by partiesViewModel.partiesUiState.collectAsState()
    Row(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(), // Fyll kortets størrelse
    ) {
        Text(
            text = "Parties",
            style = MaterialTheme.typography.titleMedium,
            /*textAlign = TextAlign.Left,*/
            modifier = Modifier
                .padding(16.dp)
                .weight(1f)

        )
        Text(
            text = "Antall stemmer",
            style = MaterialTheme.typography.titleMedium,
            /*textAlign = TextAlign.Right,*/
            modifier = Modifier
                .padding(16.dp)
                .weight(1f)
        )
    }
    Column(modifier = Modifier
        .padding(16.dp)
        .fillMaxSize(),) {


        LazyColumn(modifier = Modifier.padding(16.dp)) {
/*            items(partiesUiState.votes) { vote->
                        stemmer = vote.numberOfVotesForParty

                //}
            }*/
            items(partiesUiState.parties){ party ->
                Stemmer(party = party, stemmer = stemmer)

            }
        }
    }
}


@Composable
fun Stemmer(party: PartyInfo,stemmer:Int){

    Row(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
    ) {
        Text(
            text = party.name,
            textAlign = TextAlign.Left,
            modifier = Modifier
                .padding(16.dp)
                .weight(1f)
        )
        Text(
            text = "$stemmer",
            textAlign = TextAlign.Right,
            modifier = Modifier
                .padding(16.dp)
                .weight(1f)
        )
    }
}

