package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.data.votes

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.serialization.gson.gson
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.District
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.DistrictVotes

class IndividualVotesDataSource {
        private val path1: String =
            "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/district1.json"
        private val path2: String =
            "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/district2.json"


    private val client =
            HttpClient {
                install(ContentNegotiation) {
                    gson()
                }
            }

    suspend fun fetchDistrict1(): List<DistrictVotes> {
        val response1 = client.get(path1)

        val districtVotes: List<DistrictVotes>
        val district1Map: Map<String,String> = mapOf(response1.body())
        val numberOfVotes1 = district1Map.count{ entry -> entry.value == "1" }
        val numberOfVotes2 = district1Map.count{ entry -> entry.value == "2" }
        val numberOfVotes3 = district1Map.count{ entry -> entry.value == "3" }
        val numberOfVotes4 = district1Map.count{ entry -> entry.value == "4" }
        val votes1 = DistrictVotes(District.District1,"1", numberOfVotes1)
        val votes2 = DistrictVotes(District.District1,"2", numberOfVotes2)
        val votes3 = DistrictVotes(District.District1,"3", numberOfVotes3)
        val votes4 = DistrictVotes(District.District1,"4", numberOfVotes4)
        districtVotes = listOf(votes1,votes2,votes3,votes4)


        return districtVotes
    }

    // Should changes to fetch in one List
    suspend fun fetchDistrict2(): List<DistrictVotes> {
        val response2 = client.get(path2)

        val districtVotes: List<DistrictVotes>
        val district2Map: Map<String,String> = mapOf(response2.body())
        val numberOfVotes1 = district2Map.count{ entry -> entry.value == "1" }
        val numberOfVotes2 = district2Map.count{ entry -> entry.value == "2" }
        val numberOfVotes3 = district2Map.count{ entry -> entry.value == "3" }
        val numberOfVotes4 = district2Map.count{ entry -> entry.value == "4" }
        val votes1 = DistrictVotes(District.District2,"1", numberOfVotes1)
        val votes2 = DistrictVotes(District.District2,"2", numberOfVotes2)
        val votes3 = DistrictVotes(District.District2,"3", numberOfVotes3)
        val votes4 = DistrictVotes(District.District2,"4", numberOfVotes4)
        districtVotes = listOf(votes1,votes2,votes3,votes4)


        return districtVotes
    }
}


