
package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes

class DistrictVotesListe(val votes: List<DistrictVotes>)
