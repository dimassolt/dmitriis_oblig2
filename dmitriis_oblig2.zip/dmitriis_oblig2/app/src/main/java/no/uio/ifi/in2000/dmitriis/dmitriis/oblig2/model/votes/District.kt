package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes

enum class District() {
    District1,
    District2,
    District3

}


