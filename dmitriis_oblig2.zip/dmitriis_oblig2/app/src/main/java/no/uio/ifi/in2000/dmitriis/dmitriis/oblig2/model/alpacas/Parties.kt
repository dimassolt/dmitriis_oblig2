package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.alpacas

data class Parties(var parties: List<PartyInfo>) {
}