package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.ui.home

import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.alpacas.PartyInfo
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.data.alpacas.AlpacaPartiesRepository
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.data.alpacas.PartiesRepositoryImpl
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.District
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.DistrictVotes



data class PartiesUiState(val parties: List<PartyInfo> = emptyList(),
                          //val votes: List<DistrictVotes> = emptyList()
)

//data class PartyWithVotes(val party: PartyInfo, val votes: Int)


class HomeViewModel : ViewModel() {

    private val partiesRepository: AlpacaPartiesRepository = PartiesRepositoryImpl()
    private val _partiesUiState = MutableStateFlow(PartiesUiState())

    val partiesUiState: StateFlow<PartiesUiState> = _partiesUiState.asStateFlow()

    init {
        loadParties()
        //loadVotes()
    }


    private fun loadParties() {

        viewModelScope.launch(Dispatchers.IO) {
            _partiesUiState.update { currentPartiesUiState ->

                val parties = partiesRepository.hentParties()
                currentPartiesUiState.copy(parties = parties)

            }
        }
    }
/*    private fun loadVotes(){

      viewModelScope.launch(Dispatchers.IO) {
        _partiesUiState.update { currentVotesUiState ->
               val votes = partiesRepository.hentPartiesWithVotes(District.District3)
               currentVotesUiState.copy(votes = votes)
        }
      }
    }*/

}




































