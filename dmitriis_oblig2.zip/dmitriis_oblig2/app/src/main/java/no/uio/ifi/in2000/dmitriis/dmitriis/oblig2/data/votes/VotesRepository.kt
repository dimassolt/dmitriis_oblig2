package no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.data.votes

import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.District
import no.uio.ifi.in2000.dmitriis.dmitriis.oblig2.model.votes.DistrictVotes


interface VotesRepository {
    suspend fun hentDistrict3VotesListe(): List<DistrictVotes>
    suspend fun hentDistrict1VotesListe(): List<DistrictVotes>
    suspend fun hentDistrict2VotesListe(): List<DistrictVotes>
    suspend fun hentPartyVotesInDistrict(id:Int, district: District): DistrictVotes?


}
class VotesRepositorySamlet(
    private val district3DataSource: AggregatedVotesDataSource = AggregatedVotesDataSource(),
    val district1DataSource: IndividualVotesDataSource = IndividualVotesDataSource(),
    val district2DataSource: IndividualVotesDataSource = IndividualVotesDataSource()
) : VotesRepository {
    override suspend fun hentDistrict3VotesListe(): List<DistrictVotes> {
        return district3DataSource.fetchDistrict3()
    }
    override suspend fun hentDistrict1VotesListe(): List<DistrictVotes> {
        return district1DataSource.fetchDistrict1()
    }
    override suspend fun hentDistrict2VotesListe(): List<DistrictVotes> {
        return district2DataSource.fetchDistrict2()
    }
    override suspend fun hentPartyVotesInDistrict(id: Int, district: District): DistrictVotes? {

        val votes1 = hentDistrict1VotesListe()
        val votes2 = hentDistrict2VotesListe()
        val votes3 = hentDistrict3VotesListe()


        val trengteParty: DistrictVotes? =
            when(district){District.District1 ->  votes1.find{it.alpacaPartyId.toInt() == id }
            District.District2 -> votes2.find{it.alpacaPartyId.toInt() == id}
            District.District3 -> votes3.find{it.alpacaPartyId.toInt() == id}
        }
        return trengteParty
    }
}


